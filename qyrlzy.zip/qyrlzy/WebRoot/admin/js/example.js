// Run the script on DOM ready:
$(function(){
 $('table').visualize({type: 'pie', height: '250px', width: '370px'});
	$('table').visualize({type: 'bar', width: '370px'});
	$('table').visualize({type: 'area', width: '370px'});
	$('table').visualize({type: 'line', width: '370px'});
});